package com.example.mcs_project.DATABASE;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.mcs_project.Transaction;

public class TransactionHelper {
    private final String TABLE_NAME = "transactio";
    private DbHelper dbHelper;
    private SQLiteDatabase db;

    public TransactionHelper(Context context){
        dbHelper = new DbHelper(context);
    }

    public void insert(Transaction transaction){
        db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("furniturename",transaction.getProductName());
        contentValues.put("userid",transaction.getUserID());
        contentValues.put("totalprice",transaction.getTotalPrice());
        contentValues.put("transactiondate",transaction.getDate());
        contentValues.put("quantity",transaction.getQuantity());

        db.insert(TABLE_NAME,null,contentValues);
        db.close();

    }

    public Cursor readAllData(Integer userID){
        db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        if (db!=null){
            cursor = db.rawQuery("SELECT * FROM transactio WHERE userid = ?",new String[]{String.valueOf(userID)});
        }
        return cursor;
    }
}
