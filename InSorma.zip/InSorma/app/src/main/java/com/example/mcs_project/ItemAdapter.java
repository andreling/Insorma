package com.example.mcs_project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {
    private final RecycleInterface _recycleInterface;
    Context _context;

    ArrayList<Furniture> _furnitures;
    public ItemAdapter(Context context, ArrayList<Furniture> furnitures, RecycleInterface recycleInterface){
        _context = context;
        _furnitures = furnitures;
        _recycleInterface = recycleInterface;
    }

    @NonNull

    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(_context).inflate(R.layout.itemdisplay, parent, false);
        ItemViewHolder ViewHolder = new ItemViewHolder(itemView, _recycleInterface);
        return ViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {

        String itemname = _furnitures.get(position).itemName;
        Integer itemprice = _furnitures.get(position).itemPrice;
        Double itemrate = _furnitures.get(position).itemRate;
        String itemimage = _furnitures.get(position).itemImage;


        holder.itemName.setText(itemname);
        holder.itemPrice.setText("$ "+String.valueOf(itemprice));
        holder.itemRate.setText("Rate "+String.valueOf(itemrate));
        Picasso.with(_context).load(itemimage).fit().into(holder.itemImage);

    }

    @Override
    public int getItemCount() {
        return _furnitures.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        public TextView itemName, itemPrice, itemRate;
        public ImageView itemImage;
        public ItemViewHolder(@NonNull View itemView, RecycleInterface recycleInterface) {
            super(itemView);

            itemName = itemView.findViewById(R.id.itemName);
            itemPrice = itemView.findViewById(R.id.itemPrice);
            itemRate = itemView.findViewById(R.id.itemRate);
            itemImage = itemView.findViewById(R.id.imageView);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (_recycleInterface != null){
                        int pos = getAdapterPosition();
                        if(pos!= RecyclerView.NO_POSITION){
                            _recycleInterface.onClickItem(pos);
                        }
                    }
                }
            });
        }
    }
}