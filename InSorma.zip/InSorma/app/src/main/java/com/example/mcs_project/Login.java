package com.example.mcs_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mcs_project.DATABASE.UserHelper;

public class Login extends AppCompatActivity implements View.OnClickListener {

    EditText EmailAddress;
    AppCompatButton register;
    AppCompatButton login;
    EditText Password;
    UserHelper userHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle(" ");
        getSupportActionBar().hide();

        userHelper = new UserHelper(this);
        Password = findViewById(R.id.Password);
        EmailAddress = findViewById(R.id.Email);
        login = findViewById(R.id.LoginButton);
        register = findViewById(R.id.RegisterButton);

        login.setOnClickListener(this);
        register.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(login == view){
            if(Password.length() == 0 && EmailAddress.length() == 0){
                EmailAddress.requestFocus();
                EmailAddress.setError("Email is required");
                Password.requestFocus();
                Password.setError("Password is required");
            }
            else{
                String emailtxt = EmailAddress.getText().toString();
                String passwordtxt = Password.getText().toString();

                Users user = userHelper.auth(emailtxt,passwordtxt);

                if(user != null){
                    Intent intent = new Intent(Login.this,Home.class);
                    intent.putExtra("user",user);
                    startActivity(intent);
                }else{
                    Toast.makeText(view.getContext(),"Invalid Email or Password" , Toast.LENGTH_LONG).show();
                }
                }
            }

        else if(register == view){
            Intent intent = new Intent(this,Register.class);
            startActivity(intent);
        }

    }
}