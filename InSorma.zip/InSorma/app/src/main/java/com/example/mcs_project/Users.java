package com.example.mcs_project;

import android.os.Parcel;
import android.os.Parcelable;

public class Users implements Parcelable {
    private int id;
    String UserEmailAddress;
    String UserUsername;
    String UserPhoneNumber;
    String UserPassword;

    public Users(String userEmailAddress, String userUsername, String userPhoneNumber, String userPassword) {
        UserEmailAddress = userEmailAddress;
        UserUsername = userUsername;
        UserPhoneNumber = userPhoneNumber;
        UserPassword = userPassword;
    }

    public Users(){

    }

    protected Users(Parcel in) {
        id = in.readInt();
        UserEmailAddress = in.readString();
        UserUsername = in.readString();
        UserPhoneNumber = in.readString();
        UserPassword = in.readString();
    }

    public static final Creator<Users> CREATOR = new Creator<Users>() {
        @Override
        public Users createFromParcel(Parcel in) {
            return new Users(in);
        }

        @Override
        public Users[] newArray(int size) {
            return new Users[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserEmailAddress() {
        return UserEmailAddress;
    }

    public void setUserEmailAddress(String userEmailAddress) {
        UserEmailAddress = userEmailAddress;
    }

    public String getUserUsername() {
        return UserUsername;
    }

    public void setUserUsername(String userUsername) {
        UserUsername = userUsername;
    }

    public String getUserPhoneNumber() {
        return UserPhoneNumber;
    }

    public void setUserPhoneNumber(String userPhoneNumber) {
        UserPhoneNumber = userPhoneNumber;
    }

    public String getUserPassword() {
        return UserPassword;
    }

    public void setUserPassword(String userPassword) {
        UserPassword = userPassword;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(UserEmailAddress);
        parcel.writeString(UserUsername);
        parcel.writeString(UserPhoneNumber);
        parcel.writeString(UserPassword);
    }
}
