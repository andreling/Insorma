package com.example.mcs_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class TransactionViewHolder extends RecyclerView.ViewHolder {
    public TextView TransactionID,ProductName,Quantity,TotalPrice,TransactionDate,tv4,tv5,tv6,tv7;
    public TransactionViewHolder(@NonNull View itemView) {
        super(itemView);
        tv4 = itemView.findViewById(R.id.textView4);
        tv5 = itemView.findViewById(R.id.textView5);
        tv6 = itemView.findViewById(R.id.textView6);

        TransactionID = itemView.findViewById(R.id.tvTransactionID);
        ProductName = itemView.findViewById(R.id.tvProductName);
        Quantity = itemView.findViewById(R.id.tvQuantity);
        TotalPrice = itemView.findViewById(R.id.tvTotalPrice);
        TransactionDate = itemView.findViewById(R.id.tvTransactionDate);
    }
}
