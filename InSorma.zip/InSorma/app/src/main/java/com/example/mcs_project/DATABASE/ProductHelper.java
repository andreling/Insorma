package com.example.mcs_project.DATABASE;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.mcs_project.Furniture;


public class ProductHelper {
    private final String TABLE_NAME = "product";
    private DbHelper dbHelper;
    private SQLiteDatabase db;

    public ProductHelper(Context context){
        dbHelper = new DbHelper(context);
    }

    public void insert(Furniture furniture){
        db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("productname",furniture.getItemName());
        contentValues.put("productrating",furniture.getItemRate());
        contentValues.put("productprice",furniture.getItemPrice());
        contentValues.put("productimage",furniture.getItemImage());
        contentValues.put("productdescription",furniture.getItemDesc());
        db.insert(TABLE_NAME,null,contentValues);
        db.close();

    }
}
