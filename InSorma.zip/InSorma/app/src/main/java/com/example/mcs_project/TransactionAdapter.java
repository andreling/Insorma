package com.example.mcs_project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionViewHolder> {
    @NonNull
    Context _context;
    ArrayList userID,quantity,totalprice,transactionid,date,productname;


    public TransactionAdapter(@NonNull Context _context, ArrayList userID, ArrayList quantity, ArrayList totalprice, ArrayList transactionid, ArrayList date, ArrayList productname) {
        this._context = _context;
        this.userID = userID;
        this.quantity = quantity;
        this.totalprice = totalprice;
        this.transactionid = transactionid;
        this.date = date;
        this.productname = productname;
    }

    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(_context).inflate(R.layout.layout_transaction_detail, parent, false);
        TransactionViewHolder ViewHolder = new TransactionViewHolder(itemView);
        return ViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        holder.ProductName.setText(String.valueOf(productname.get(position)));
        holder.TransactionID.setText("Transaction ID " + String.valueOf(transactionid.get(position)));
        holder.Quantity.setText(String.valueOf(quantity.get(position)));
        holder.TotalPrice.setText("$ " + String.valueOf(totalprice.get(position)));
        holder.TransactionDate.setText(String.valueOf(date.get(position)));

    }

    @Override
    public int getItemCount() {
        return transactionid.size();
    }
}
