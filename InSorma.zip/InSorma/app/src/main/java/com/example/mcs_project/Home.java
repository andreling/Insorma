package com.example.mcs_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Home extends AppCompatActivity implements RecycleInterface{

    Users user;
    RecyclerView recyclerItem;
    TextView name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().setTitle("InSorma");

        user = getIntent().getParcelableExtra("user");
        name = findViewById(R.id.HelloUser);
        recyclerItem = findViewById(R.id.recyclerviewitem);
        ItemAdapter itemadapter = new ItemAdapter(this, MainActivity.furniture, this);
        recyclerItem.setAdapter(itemadapter);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerItem.setLayoutManager(manager);
        name.setText("Welcome "+user.getUserUsername().toString());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.homeButton:
                break;
            case R.id.transactionButton:
                Intent item2 = new Intent(this,TransactionPage.class);
                item2.putExtra("user",user);
                startActivity(item2);
                break;
            case R.id.ProfileButton:
                Intent item3 = new Intent(this,ProfilePage.class);
                item3.putExtra("user",user);
                startActivity(item3);
                break;
            case R.id.aboutButton:
                Intent item4 = new Intent(this,About.class);
                startActivity(item4);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClickItem(int position) {
        Intent intent = new Intent(this, product_detail_page.class);
        intent.putExtra("productData", position);
        intent.putExtra("user",user);
        startActivity(intent);
    }
}