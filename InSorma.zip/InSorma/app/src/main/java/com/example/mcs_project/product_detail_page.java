package com.example.mcs_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mcs_project.DATABASE.TransactionHelper;
import com.example.mcs_project.DATABASE.UserHelper;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class product_detail_page extends AppCompatActivity implements View.OnClickListener {

    ImageView productPhoto;
    TextView productName;
    TextView productPrice;
    TextView productRate;
    EditText quantity;
    Integer position;
    AppCompatButton buy;
    String transactionIDcombiner;
    String CurrentDate;
    DateFormat df;
    DateFormat date;
    Integer userIdPosition;
    TransactionHelper transactionHelper;
    Users user;

    ImageButton backbutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail_page);
        getSupportActionBar().hide();

        position = getIntent().getIntExtra("productData",0);

        user = getIntent().getParcelableExtra("user");
        userIdPosition = user.getId();

        transactionHelper = new TransactionHelper(this);
        backbutton = findViewById(R.id.backbuttonprofiledetail);
        productPhoto = findViewById(R.id.detailPhoto);
        productPrice = findViewById(R.id.detailProductPrice);
        productRate = findViewById(R.id.detailProductRate);
        buy = findViewById(R.id.buy);
        quantity = findViewById(R.id.quantity);
        productName = findViewById(R.id.detailProductName);

        productName.setText(MainActivity.furniture.get(position).itemName);
        productPrice.setText("$ " + String.valueOf(MainActivity.furniture.get(position).itemPrice));
        productRate.setText(String.valueOf(MainActivity.furniture.get(position).itemRate));
        Picasso.with(this).load(MainActivity.furniture.get(position).itemImage).fit().into(productPhoto);


        buy.setOnClickListener(this);
        backbutton.setOnClickListener(this);

    }



    @Override
    public void onClick(View view) {
        if(view == buy){
            date = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss");
            df = new SimpleDateFormat("HHmmss");

            CurrentDate = date.format(Calendar.getInstance().getTime());
            transactionIDcombiner = df.format(Calendar.getInstance().getTime());
            Integer value = Integer.valueOf(quantity.getText().toString());

            Transaction transaction = new Transaction(userIdPosition,value,value*MainActivity.furniture.get(position).itemPrice,CurrentDate,MainActivity.furniture.get(position).itemName);
            transactionHelper.insert(transaction);

            Toast.makeText(view.getContext(),"Success" , Toast.LENGTH_LONG).show();
        }
        else if(view == backbutton){
            Intent intent = new Intent(product_detail_page.this,Home.class);
            intent.putExtra("user",user);
            startActivity(intent);
        }
    }
}