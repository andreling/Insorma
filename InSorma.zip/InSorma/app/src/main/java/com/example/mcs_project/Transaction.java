package com.example.mcs_project;

public class Transaction {
    Integer TransactionID;
    Integer UserID;
    Integer Quantity;
    Integer TotalPrice;
    String Date;
    String ProductName;

    public Transaction( Integer userID, Integer quantity, Integer totalPrice, String date, String productName) {
        UserID = userID;
        Quantity = quantity;
        TotalPrice = totalPrice;
        Date = date;
        ProductName = productName;
    }

    public Integer getTransactionID() {
        return TransactionID;
    }

    public void setTransactionID(Integer transactionID) {
        TransactionID = transactionID;
    }

    public Integer getUserID() {
        return UserID;
    }

    public void setUserID(Integer userID) {
        UserID = userID;
    }

    public Integer getQuantity() {
        return Quantity;
    }

    public void setQuantity(Integer quantity) {
        Quantity = quantity;
    }

    public Integer getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(Integer totalPrice) {
        TotalPrice = totalPrice;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }
}
