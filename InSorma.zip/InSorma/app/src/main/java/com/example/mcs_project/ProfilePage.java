package com.example.mcs_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mcs_project.DATABASE.UserHelper;

public class ProfilePage extends AppCompatActivity implements View.OnClickListener {

    boolean usernametxt = false;
    UserHelper userHelper;
    TextView email;
    TextView phone;
    TextView username;
    ImageView photo;
    EditText edit;
    AppCompatButton save;
    Users user;
    AppCompatButton delete;
    AppCompatButton editButton;
    AppCompatButton logout;

    ImageButton backbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);
        getSupportActionBar().hide();
        user = getIntent().getParcelableExtra("user");

        backbutton =  findViewById(R.id.backbutton);
        userHelper = new UserHelper(this);
        username = findViewById(R.id.usernameview);
        email = findViewById(R.id.emailview);
        phone = findViewById(R.id.phoneview);
        edit = findViewById(R.id.editusername);
        save = findViewById(R.id.savebutton);
        delete = findViewById(R.id.deletebutton);
        editButton = findViewById(R.id.editbutton);
        logout = findViewById(R.id.logoutbutton);
        photo = findViewById(R.id.profilephoto);

        username.setText(user.UserUsername);
        email.setText(user.UserEmailAddress);
        phone.setText(user.UserPhoneNumber);
        photo.setImageResource(R.drawable.user);

        save.setVisibility(View.GONE);
        edit.setVisibility(View.GONE);
        editButton.setVisibility(View.VISIBLE);

        editButton.setOnClickListener(this);
        backbutton.setOnClickListener(this);
        save.setOnClickListener(this);
        delete.setOnClickListener(this);
        logout.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        if(view == save){
            usernametxt = userHelper.uniqueName(edit.getText().toString());
            if(usernametxt){
                String Nametxt = edit.getText().toString();
                user.setUserUsername(Nametxt);
                userHelper.update(user);
                username.setText(user.UserUsername);
                username.setVisibility(View.VISIBLE);
                save.setVisibility(View.GONE);
                edit.setVisibility(View.GONE);
                editButton.setVisibility(View.VISIBLE);
            }
            else{
                Toast.makeText(view.getContext(),"Username is Not Unique" , Toast.LENGTH_LONG).show();
            }

        }
        else if(view == delete){
            userHelper.delete(user);
            Intent intent = new Intent(this,Login.class);
            startActivity(intent);
        }

        else if(view == editButton){
            username.setVisibility(View.GONE);
            save.setVisibility(View.VISIBLE);
            edit.setVisibility(View.VISIBLE);
            editButton.setVisibility(View.GONE);
        }

        else if(view == backbutton){
            Intent intent = new Intent(this,Home.class);
            intent.putExtra("user",user);
            startActivity(intent);
        }

        else if(view == logout){
            Intent intent = new Intent(this,Login.class);
            startActivity(intent);
        }

    }

}