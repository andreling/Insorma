package com.example.mcs_project.DATABASE;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class DbHelper extends SQLiteOpenHelper {

    private final String CREATE_TABLE_USERS = "CREATE TABLE users(id integer PRIMARY KEY AUTOINCREMENT," +
            "username text NOT NULL, " +
            "password text NOT NULL," +
            "email text NOT NULL," +
            "phone text NOT NULL)";

    private final String CREATE_TABLE_PRODUCT = "CREATE TABLE product(productname text PRIMARY KEY," +
            "productrating real NOT NULL," +
            "productprice integer NOT NULL," +
            "productimage text NOT NULL," +
            "productdescription text NOT NULL)";

    private final String CREATE_TABLE_TRANSACTION = "CREATE TABLE transactio (transactionid integer PRIMARY KEY AUTOINCREMENT," +
            "furniturename text NOT NULL," +
            "userid integer NOT NULL," +
            "totalprice integer NOT NULL," +
            "transactiondate text NOT NULL," +
            "quantity integer NOT NULL)";


    public DbHelper(@Nullable Context context ) {
        super(context,"sqlite", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(CREATE_TABLE_USERS);
            sqLiteDatabase.execSQL(CREATE_TABLE_PRODUCT);
            sqLiteDatabase.execSQL(CREATE_TABLE_TRANSACTION);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS users");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS product");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS transactio");

        onCreate(sqLiteDatabase);
    }
}
