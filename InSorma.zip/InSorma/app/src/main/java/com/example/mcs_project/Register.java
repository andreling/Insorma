package com.example.mcs_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mcs_project.DATABASE.UserHelper;

import java.util.ArrayList;

public class Register extends AppCompatActivity implements View.OnClickListener {

    boolean checkform = false;
    boolean checkuniquename = false;
    boolean checkuniqueemail= false;
    UserHelper userHelper;

    EditText email;
    EditText username;
    EditText phonenumber;
    EditText password;
    AppCompatButton register;
    AppCompatButton login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().setTitle(" ");
        getSupportActionBar().hide();

        userHelper = new UserHelper(this);
        email = findViewById(R.id.RegisEmail);
        username = findViewById(R.id.RegisUsername);
        phonenumber = findViewById(R.id.RegisPhoneNumber);
        password = findViewById(R.id.RegisPassword);
        register = findViewById(R.id.RegisRegister);
        login = findViewById(R.id.RegisLogin);


        register.setOnClickListener(this);
        login.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == register){
            checkform = validate();
            checkuniquename = userHelper.uniqueName(username.getText().toString());
            checkuniqueemail = userHelper.uniqueEmail(email.getText().toString());

            if(checkform && checkuniquename && checkuniqueemail){
                String Nametxt = username.getText().toString();
                String Phonetxt = phonenumber.getText().toString();
                String Emailtxt = email.getText().toString();
                String Passwordtxt = password.getText().toString();

                Users user = new Users(Emailtxt,Nametxt,Phonetxt,Passwordtxt);
                userHelper.insert(user);
                Intent intent = new Intent(Register.this,Login.class);
                startActivity(intent);
            }
            else{
                if(!checkuniquename && !checkuniqueemail){
                    username.requestFocus();
                    username.setError("Username Not Unique");
                    email.requestFocus();
                    email.setError("Email Not Unique");
                }
                else{
                    if(!checkuniqueemail){
                        email.requestFocus();
                        email.setError("Email Not Unique");
                    }
                    else if(!checkuniquename){
                        username.requestFocus();
                        username.setError("Username Not Unique");
                    }
                }
            }
        }
        else if(view == login){
            Intent intent = new Intent(Register.this,Login.class);
            startActivity(intent);
        }
    }

    public boolean validate(){
        if(username.length() == 0 && email.length() == 0 && phonenumber.length() == 0 && password.length() == 0){
            username.requestFocus();
            username.setError("This field cannot be blank");
            email.requestFocus();
            email.setError("This field cannot be blank");
            password.requestFocus();
            password.setError("This field cannot be blank");
            phonenumber.requestFocus();
            phonenumber.setError("This field cannot be blank");
            return false;
        }
        else if(username.length() == 0){
            username.requestFocus();
            username.setError("This field cannot be blank");
            return false;
        }
        else if(email.length() == 0){
            email.requestFocus();
            email.setError("This field cannot be blank");
            return false;
        }
        else if(password.length() == 0){
            password.requestFocus();
            password.setError("This field cannot be blank");
            return false;
        }
        else if(phonenumber.length() == 0){
            phonenumber.requestFocus();
            phonenumber.setError("This field cannot be blank");
            return false;
        }
        else if(!email.getText().toString().matches(".*\\b.com\\b")){
            email.requestFocus();
            email.setError("Email must ends with .com");
            return false;
        }

        else if(!phonenumber.getText().toString().matches("^[0-9-]+$")){
            phonenumber.requestFocus();
            phonenumber.setError("Must contain number only");
            return false;
        }
        else if(!password.getText().toString().matches("^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$")){
            password.requestFocus();
            password.setError("Must contain atleast 1 letter and 1 number");
            return false;
        }
        else if(username.length() < 3 || username.length() > 20){
            username.requestFocus();
            username.setError("Username length must be greater than 3");
            return false;
        }
        return true;
    }

}