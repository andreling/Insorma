package com.example.mcs_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.mcs_project.DATABASE.DbHelper;
import com.example.mcs_project.DATABASE.TransactionHelper;

import java.util.ArrayList;

public class TransactionPage extends AppCompatActivity {
    RecyclerView recyclerViewTransaction;
    ImageButton backbutton;
    TransactionHelper transactionHelper;
    ArrayList<Integer> userID,quantity,totalprice,transactionid;
    ArrayList<String> date,productname;
    Users user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_page);
        getSupportActionBar().hide();
        user = getIntent().getParcelableExtra("user");
        backbutton = findViewById(R.id.backbuttontransactiondetail);

        transactionHelper = new TransactionHelper(TransactionPage.this);
        transactionid = new ArrayList<>();
        userID = new ArrayList<>();
        quantity = new ArrayList<>();
        totalprice = new ArrayList<>();
        date = new ArrayList<>();
        productname = new ArrayList<>();

        recyclerViewTransaction = findViewById(R.id.recyclerviewtransaction);
        TransactionAdapter transactionAdapter = new TransactionAdapter(this, userID,quantity,totalprice ,transactionid,date,productname);
        recyclerViewTransaction.setAdapter(transactionAdapter);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerViewTransaction.setLayoutManager(manager);
        displaydata();
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TransactionPage.this,Home.class);
                intent.putExtra("user",user);
                startActivity(intent);
            }
        });
    }


    void displaydata(){
        Cursor cursor = transactionHelper.readAllData(user.getId());
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No Data",Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                transactionid.add(cursor.getInt(0));
                productname.add(cursor.getString(1));
                userID.add(cursor.getInt(2));
                totalprice.add(cursor.getInt(3));
                date.add(cursor.getString(4));
                quantity.add(cursor.getInt(5));

            }
        }
    }
}