package com.example.mcs_project.DATABASE;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.mcs_project.Furniture;
import com.example.mcs_project.Users;

public class UserHelper {
    private final String TABLE_NAME = "users";
    private DbHelper dbHelper;
    private SQLiteDatabase db;

    public UserHelper(Context context){
        dbHelper = new DbHelper(context);
    }

    public void insert(Users user){
        db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",user.getUserUsername());
        contentValues.put("password",user.getUserPassword());
        contentValues.put("email",user.getUserEmailAddress());
        contentValues.put("phone",user.getUserPhoneNumber());
        db.insert(TABLE_NAME,null,contentValues);
        db.close();

    }

    public Users auth(String email, String password){
        db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE email = ? and password = ?",
                new String[]{email,password});

        Users user = null;
        if(cursor != null && cursor.getCount() > 0){
            cursor.moveToFirst();
            user = new Users();
            user.setId(cursor.getInt(0));
            user.setUserUsername(cursor.getString(1));
            user.setUserPassword(cursor.getString(2));
            user.setUserEmailAddress(cursor.getString(3));
            user.setUserPhoneNumber(cursor.getString(4));
            cursor.close();
        }
        db.close();
        return user;
    }

    public void update(Users user){
        db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",user.getUserUsername());
        db.update(TABLE_NAME, contentValues, "id = ?", new String[]{user.getId()+""});
        db.close();
    }

    public boolean uniqueName(String name){
        String nametxt;
        db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users",null);

        cursor.moveToFirst();

        while (cursor.isAfterLast()==false){
            nametxt = cursor.getString(1);
            if(name.equals(nametxt)){
                cursor.close();
                db.close();
                return false;
            }
            cursor.moveToNext();
        }
        cursor.close();
        db.close();
        return true;
    }

    public boolean uniqueEmail(String email){
        String emailtxt;
        db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users",null);

        cursor.moveToFirst();

        while (cursor.isAfterLast()==false){
            emailtxt = cursor.getString(3);
            if(email.equals(emailtxt)){
                cursor.close();
                db.close();
                return false;
            }
            cursor.moveToNext();
        }
        cursor.close();
        db.close();
        return true;
    }


    public void delete(Users user){
        db = dbHelper.getWritableDatabase();
        db.delete(TABLE_NAME, "id = ?", new String[]{user.getId()+""});
        db.close();
    }

}
