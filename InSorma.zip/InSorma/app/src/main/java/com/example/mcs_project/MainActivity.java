package com.example.mcs_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.mcs_project.DATABASE.ProductHelper;
import com.example.mcs_project.DATABASE.UserHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  {


    public static ArrayList<Furniture> furniture =  new ArrayList<>();
    private RequestQueue mQueqe;
    ProductHelper productHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        productHelper = new ProductHelper(this);
        mQueqe = Volley.newRequestQueue(this);
        jsonParse();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(MainActivity.this,Login.class));
                finish();
            }
        }, 4000);
    }

    private void jsonParse(){

        String Url = "https://bit.ly/InSOrmaJSON";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, Url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("furnitures");
                            for(int i = 0 ; i < jsonArray.length();i++){
                                JSONObject furnitures = jsonArray.getJSONObject(i);

                                String product_name = furnitures.getString("product_name");
                                Double rating = furnitures.getDouble("rating");
                                Integer price = furnitures.getInt("price");
                                String image = furnitures.getString("image");
                                String desc = furnitures.getString("description");

                                furniture.add(new Furniture(product_name, desc, price, rating, image ));
                                Furniture furnituress = new Furniture(product_name,desc,price,rating,image);
                                productHelper.insert(furnituress);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueqe.add(request);
    }
}