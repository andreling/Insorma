package com.example.mcs_project;

public interface RecycleInterface {
    void onClickItem (int position);
}
